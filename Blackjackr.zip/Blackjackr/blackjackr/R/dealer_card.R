#' Determines which dealer cards can match with the inputted player hand.
#' 
#' @description The player hand is inputted with a hash map. This function determines all of the possible dealer visible cards which could exist given the hands in the player's hand. These are then added as keys to the inputted dictionary. 
#'
#' @param ind Numeric: The index describing the player hand with the dealer card set to 0. For information on the indexing system, see section 1 of the accompanying thesis document.
#' @param dictionary Hash map: The hash map to which the valid positions will be added.
#'
#' @return Hash map: The same hash map that was inputted with the new valid hands added .
#' @export
#'
#' @examples dealer_card(101100000100, dictionary)
dealer_card = function(ind,dictionary, number_of_decks){
  #if(number_of_decks > 2)(number_of_decks = 9/4)#I cant allow 10 aces or ten 2 cards to be drawn. It ruins my indexing system. 10 aces == 1 10 card
  temp = ind
  ind = strsplit(as.character(ind), "")[[1]]
  ind = rev(ind[2:length(ind)])
  for(j in 1:10){
    if(as.integer(ind[j]) < 4*number_of_decks){#timesdecks
      dictionary[[as.character(temp + 10000000000*(j-1))]] = as.numeric(0)}}
  return(dictionary)}
