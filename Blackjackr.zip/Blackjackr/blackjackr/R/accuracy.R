accuracy = function(strategy_1, strategy_2){
  count = 0
  labels1 = names(strategy_1)
  labels2 = names(strategy_2)
  for(i in labels1){
    if(is.null(strategy_2[[i]]) == F){
      if(strategy_1[[i]] == strategy_2[[i]])(count = count+ 1)
  }}
  return(count/length(names(strategy_1)))
}