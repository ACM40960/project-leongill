#' Given a list of data, outputs the optimal strategy for that data.
#'
#' @description This function is embedded in full_strategy() but is required separately to analyse the analytic derived data to produce the optimal data.
#'
#' @param data Vector: Vector of four hash maps with keys corresponding to all possible positions. In order they are the position player scores, the cards in the player's hand, the number of cards in the player's hand and the player's expected return when sticking at the position. 
#' @param blackjack_return Numeric: The amount that blackjack returns. For 3:2 the amount this is 1.5. For 2:1 this is 2.
#' @param include_double_down Logical: Whether double down is permitted in your choice of game.
#' @param include_surrender Logical: Whether surrender is permitted in your choice of game.
#' @param include_split Integer: The number of splits allowed. 0 is equivalent to not allowing splitting.
#' @param number_of_decks Integer: The number of decks used to derive the analytic values. This is the number passed to import_perfect().
#' @param surrender_on_blackjack  Logical: If the player can surrender, this determines if they can surrender when the dealer may have blackjack. 
#' @param verbose Logical: Whether to output the strategy as a hash map(FALSE) or as a data frame(TRUE).
#' 
#' @return Hash map/dataframe: Hash map with keys representing positions and values representing the optimal choice given the specified rules. If verbose == T, data frame with score/strategy and hand size information.
#' @export
#'
#' @examples data_analysis(import_perfect(1), include_double_down = F, include_surrender = F)
data_analysis = function(data, blackjack_return = 1.5, include_double_down = F, include_surrender = F, include_split = 0, number_of_decks = 1, surrender_on_blackjack = F, verbose = F){
  invisible(options(scipen=999) )
  scores = data[[1]]
  cards = data[[2]]
  hand_size = data[[3]]#Could replace with length(cards)
  stick_return = data[[4]]
  labels = names(stick_return)
  hit_return = hash::hash(labels, -1)#Could just make equal to stick as we edit all values later
  split_stick_returns = hash::hash()
  double_return = hash::hash(labels,-2)
  surrender = hash::hash(labels, -2)
  
  for(i in labels){
    if(hand_size[[i]] == 2){
      split_stick_returns[[i]] = stick_return[[i]]#split doesnt get blackjack. need to keep these for later
      if(scores[[i]] == 21){
        stick_return[[i]] = (blackjack_return)*stick_return[[i]]}}}#Blackjack gets double score
  
  if(include_double_down == F){ 
    for(current_num in 10:2){
      for(i in labels){#problem
        if(hand_size[[i]] == current_num){
          expected_value = 0
          current_hand = cards[[i]]
          hit_return[[i]] = 0
          for(j in 0:9){
            if(sum(current_hand == j) != 9){
              temp = as.character(as.numeric(i) + 10^j)
              p = probability(current_hand, j, number_of_decks)
              if(p != 0){
                if(score(temp)< 22){
                  if(stick_return[[temp]] >= hit_return[[temp]]){
                    expected_value = expected_value + p*stick_return[[temp]]}
                  if(stick_return[[temp]] < hit_return[[temp]]){
                    expected_value = expected_value + p*hit_return[[temp]]}
                }
                if(score(temp) > 21){
                  expected_value = expected_value - p}
              }}}
          hit_return[[i]] = expected_value
        }}}}
  
  
  
  if(include_double_down == T){ 
    for(current_num in 10:2){
      for(i in labels){#problem
        if(hand_size[[i]] == current_num){
          expected_value = 0
          current_hand = cards[[i]]
          hit_return[[i]] = 0
          double_return[[i]] = 0
          for(j in 0:9){
            if(sum(current_hand == j) != 9){
              temp = as.character(as.numeric(i) + 10^j)
              p = probability(current_hand, j, number_of_decks)
              if(p != 0){
                if(score(temp)< 22){
                  double_return[[i]] = double_return[[i]] + 2*p*stick_return[[temp]]
                  expected_value = expected_value + p*max(hit_return[[temp]], stick_return[[temp]], double_return[[temp]], -1)
                }
                if(score(temp) > 21){
                  expected_value = expected_value - p
                  double_return[[i]] = double_return[[i]] - 2*p}
              }}}
          hit_return[[i]] = expected_value
        }}}}
  
  
  #implement surrender
  if(include_surrender == T){
    surrender = hash::hash(labels, -2)
    for(i in labels){
      if(hand_size[[i]] == 2){
        if(surrender_on_blackjack == T){
          surrender[[i]] = -0.5
        }
        if(surrender_on_blackjack == F){
          if(tail(cards[[i]], 1)!= 0 && tail(cards[[i]], 1)!= 1){
            surrender[[i]] = -0.5}}    
      }}}
  
  
  #Choose optimal move for each position
  
  optimal = hash::hash(labels,0)
  optimal_value = hash::hash(labels,0)
  for(i in labels){
    moves =
      optimal[[i]] = which.max(c(stick_return[[i]], hit_return[[i]], double_return[[i]], surrender[[i]])) - 1
    optimal_value[[i]] = max(c(split_stick_returns[[i]], hit_return[[i]], double_return[[i]]))
  }
  
  #Implement splitting
  #Could add in the no hitting on split aces. Just use the stick expected returns
  if(include_split > 0){
    split_return = hash::hash()
    for(i in 0:9){#dealer card
      for(j in 0:9){#the card of which a pair is drawn
        split_exp_return = 0
        label = as.character(10^11 + i*10^10+2*10^j)#pair label
        for(k in 0:9){#after splitting you may draw 1 of 10 hands
          p = probability(played_cards = c(i,j,j), to_draw = k, number_of_decks = number_of_decks)#You drew a pair so j has been drawn twice
          split_exp_return = split_exp_return + p*optimal_value[[as.character(10^11 + i*10^10+10^j + 10^k)]]
        }
        split_return[[label]] = split_exp_return*2#We double as we double the bet upon this action
      }
    }
    
    for(i in names(split_return)){
      if(split_return[[i]] > optimal_value[[i]]){
        optimal[[as.character(as.numeric(i) + 10^11)]] = 1#Then this position should split
      }
    }}
  if(verbose == F){
    return(optimal)}
  
  if(verbose == T){
    return(data.frame("Scores" = values(scores), "Cards in Hand" = values(hand_size)[1:length(labels)], "Optimal Move" = values(optimal)[1:length(labels)], row.names = names(optimal)[1:length(labels)]))
  }
}
