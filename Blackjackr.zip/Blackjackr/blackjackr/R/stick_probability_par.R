#' Estimates the expected return for sticking at a position with MC simulations done in parallel
#' 
#' @description Given a position, the player hand is set as well as the dealer's first card which is implicit in the position. The dealer then draws and sticks on or above 17. 
#'
#' @param number_of_simulations Integer: The number of simulations used to approximate the expected player return when sticking on each position.
#' @param player_hand_score Integer: The score associated with the player hand. Outputted by score(). 
#' @param hand_vector Vector: The cards in the position with the dealer's visible card at the end. Outputted by hand(). 
#' @param cores Integer: The number of cores to use on the computation. Default is all. 
#' 
#' @return Numeric: The players expected return per game sticking on the position. 
#' @export
#'
#' @examples stick_probability_par(10^7, 19, c(2,8,9,0))
stick_probability_par = function(number_of_simulations, number_of_decks, player_hand_score, hand_vector, cores = parallel::detectCores()){
  cl = parallel::makeCluster(cores)
  parallel::clusterExport(cl, c("stick_probability"), envir=environment())
  output =  parallel::parLapply(cl,rep(number_of_simulations/cores,cores),fun =  function(x)(stick_probability(count = x, number_of_decks = number_of_decks, player_score = player_hand_score , base_hand =  hand_vector)))
  parallel::stopCluster(cl)
  return(mean(unlist(output)))
}