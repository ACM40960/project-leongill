#' Import the analytic probabilities for sticking on all positions from .csv files.
#' 
#' @description Import the analytic probabilities for sticking on all positions from .csv files which were obtained using Python 3.
#'
#' @param number_of_decks Integer: The number of decks in the game under analysis.
#'
#' @return Hash map: The same hash map that was inputted with the new valid hands added .
#' @export
#'
#' @examples import_perfect(number_of_decks = 1)
import_perfect = function(number_of_decks = 1){
  options = c("perfect_strategy_1.csv","perfect_strategy_2.csv","perfect_strategy_3.csv","perfect_strategy_4.csv","perfect_strategy_5.csv","perfect_strategy_6.csv","perfect_strategy_7.csv","perfect_strategy_8.csv")
    perfect = read.csv(options[number_of_decks], row.names = 2)
    labels = rownames(perfect)
  perfect = c(hash(labels, perfect$Scores),
              hash(labels,sapply(labels, FUN = hand, simplify = TRUE, USE.NAMES = F)),
              hash(labels,sapply(labels, FUN = function(x)(length(hand(x))-1))),
              hash(labels, perfect$Stick.Expected.Return))
  return(perfect)}