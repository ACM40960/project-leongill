#include <Rcpp.h>
#include <random>
#include <map>
using namespace Rcpp;


//' @name play_games
//' 
//' @title Simulates full games given a strategy
//'
//' @description Strategy input as separate vectors of keys and values. Output is the average return per game of the strategy.
//' @param count Integer: Simulations to be played.
//' @param index Numeric: The strategy keys given in numeric form. Requires invisible(options(scipen=999)) before conversion.
//' @param optimal Integer: The optimal player move for the associated position.
//' @param blackjack_return Numeric: The amount payed for blackjack.
//' 
//' @return Approximation of the player expected return per game


// [[Rcpp::export]]
double play_games2(int count, double blackjack_return, int number_of_decks,  NumericVector index, IntegerVector optimal){
  int rng = 0, base_player_score, base_player_aces, pairs, player_cards, match_mult, surrender, pair_card;
  double ties = 0, dealer_wins = 0, player_wins = 0, player_hand , player_score, dealer_score , player_aces , dealer_aces,  base_player_hand;
  std::map<double, int> map1;
  for (int i = 0; i < index.size(); ++i)(map1[index[i]] = optimal[i]);
  std::random_device rd;
  std::mt19937 eng(rd());
  NumericVector bc = {4,16,4,4,4,4,4,4,4,4}, pair_cards;
  for (int i = 0; i < 10; i++)( bc[i] = bc[i] * number_of_decks);
  //consider special check so we dont need to ace check every time on dealer
  while (count > 0) {
    player_cards = -1, base_player_hand = 100000000000, dealer_score = 0, dealer_aces = 0, base_player_score = 0, base_player_aces = 0, pairs = 0,  pair_cards = {};
    NumericVector c = {bc[0],bc[1],bc[2],bc[3],bc[4],bc[5],bc[6],bc[7],bc[8],bc[9]};
    while (dealer_score < 17) {
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      if(rng > 1)(dealer_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        dealer_score += (11 - rng);
        dealer_aces += (1 - rng);}
      if (player_cards == -1){
        base_player_hand += 10000000000*rng;      
        player_cards += 1;}
      while (dealer_score > 21 and dealer_aces > 0){
        dealer_score -= 10;
        dealer_aces -= 1;}}
    
    // adding in the trivial hands will remove all of these checks which is good
    std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
    pair_card = distr(eng);
    c[pair_card] -= 1;
    base_player_hand += pow(10,pair_card);
    if(pair_card > 1)(base_player_score += pair_card);
    if(pair_card < 2){
      //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
      base_player_score += (11 - pair_card);
      base_player_aces += (1 - pair_card);};
    
    while (base_player_score > 21 and base_player_aces > 0){
      base_player_score -= 10;
      base_player_aces -= 1;}

//now make the vector and draw the cards
    while(pair_cards.size() < pairs + 1){
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      if(map1[base_player_hand + pow(10,rng)] == 4){
        pairs += 1;};
      if(map1[base_player_hand + pow(10,rng)] != 4){
        pair_cards.push_back(rng);};}

    for(int i:pair_cards){
    player_score = base_player_score, player_aces = base_player_aces, player_hand = base_player_hand + pow(10,i), match_mult = 1, surrender = 0, player_cards = 2;
      if(i > 1)(player_score += i);
      if(i < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        player_score += (11 - i);
        player_aces += (1 - i);};
      
      while (player_score > 21 and player_aces > 0){
        player_score -= 10;
        player_aces -= 1;};
      
      
      
    
    while (map1[player_hand] == 1) {//was player_score < 12 for some reason#
      player_cards += 1;
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      player_hand += pow(10,rng);
      if(rng > 1)(player_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        player_score += (11 - rng);
        player_aces += (1 - rng);};
      
      while (player_score > 21 and player_aces > 0){
        player_score -= 10;
        player_aces -= 1;}}
    
    
    //Double Down
    if(map1[player_hand] == 2) {
      match_mult = 2;
      player_cards += 1;
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      if(rng > 1)(player_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        player_score += (11 - rng);
        player_aces += (1 - rng);};
      while (player_score > 21 and player_aces > 0){
        player_score -= 10;
        player_aces -= 1;}}
    
    //surrender
    if(map1[player_hand] == 3) {
      surrender = 1;
      dealer_wins += 0.5;
    }
    
    if(surrender == 0){
      if (player_score < 22){
        if (player_score > dealer_score)(player_wins += 1*match_mult);
        if (player_score < dealer_score and dealer_score < 22)(dealer_wins += 1*match_mult);
        if (dealer_score > 21)(player_wins +=1*match_mult);
        if (player_score == dealer_score)(ties += 1);}
      if (player_score > 21)(dealer_wins += 1*match_mult);
      if (player_score == 21 and player_cards == 2 and dealer_score != 21)(player_wins += (blackjack_return - 1));
    }
    
    }
    count -= 1;
  }
  return((player_wins - dealer_wins)/(player_wins + dealer_wins + ties));
}