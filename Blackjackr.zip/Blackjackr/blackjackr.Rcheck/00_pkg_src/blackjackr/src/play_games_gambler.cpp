#include <Rcpp.h>
#include <random>
#include <map>
using namespace Rcpp;


// [[Rcpp::export]]
NumericVector play_games_gambler(int count, int repeats, NumericVector index, IntegerVector optimal){
  int rng = 0, count_total = count, current_repeat = 0;
  std::map<double, int> map1;
  for (int i = 0; i < index.size(); ++i)(map1[index[i]] = optimal[i]);
  std::random_device rd;
  std::mt19937 eng(rd());
  NumericVector outcome;
  //consider special check so we dont need to ace check every time on dealer
  while(current_repeat < repeats){
  double ties = 0, dealer_wins = 0, player_wins = 0;
  current_repeat += 1;
  int count  = count_total;
  while (count > 0) {
    int player_cards = -1, match_mult = 1, surrender = 0;
    IntegerVector c = {4,16,4,4,4,4,4,4,4,4};//notice the no equels,,,,
    double player_hand = 100000000000, player_score = 0, dealer_score = 0, player_aces = 0, dealer_aces = 0;
    
    while (dealer_score < 17) {
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      if(rng > 1)(dealer_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        dealer_score += (11 - rng);
        dealer_aces += (1 - rng);}
      
      
      if (player_cards == -1){
        player_hand += 10000000000*rng;      
        player_cards+= 1;}
      while (dealer_score > 21 and dealer_aces > 0){
        dealer_score -= 10;
        dealer_aces -= 1;}}
    
    // adding in the trivial hands will remove all of these checks which is good
    
    
    
    while (map1[player_hand] == 1 or player_cards < 2) {//was player_score < 12 for some reason
      player_cards += 1;
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      c[rng] -= 1;
      player_hand += pow(10,rng);
      if(rng > 1)(player_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        player_score += (11 - rng);
        player_aces += (1 - rng);};
      
      while (player_score > 21 and player_aces > 0){
        player_score -= 10;
        player_aces -= 1;}}
    
    
    //Double Down
    if(map1[player_hand] == 2) {
      match_mult = 2;
      player_cards += 1;
      std::discrete_distribution<> distr({c[0],c[1],c[2],c[3],c[4],c[5],c[6],c[7],c[8],c[9]});
      rng = distr(eng);
      if(rng > 1)(player_score += rng);
      if(rng < 2){
        //2 operations here, could be removed entirely with a lot of effort send Ace to 1 and 10 to 0
        player_score += (11 - rng);
        player_aces += (1 - rng);};
      while (player_score > 21 and player_aces > 0){
        player_score -= 10;
        player_aces -= 1;}}
    
    //surrender
    if(map1[player_hand] == 3) {
      surrender = 1;
    }
    
    if(surrender == 1){
      dealer_wins += 0.5;
    }
    
    if(surrender == 0){
      if (player_score < 22){
        if (player_score > dealer_score)(player_wins += 1*match_mult);
        if (player_score < dealer_score and dealer_score < 22)(dealer_wins += 1*match_mult);
        if (dealer_score > 21)(player_wins +=1*match_mult);
        if (player_score == dealer_score)(ties += 1);}
      if (player_score > 21)(dealer_wins += 1*match_mult);
      if (player_score == 21 and player_cards == 2 and dealer_score != 21)(player_wins += 1);
    }
    
    
    count -= 1;
  }
  outcome.push_back((player_wins - dealer_wins));}
  
  return(wrap(outcome));
}
