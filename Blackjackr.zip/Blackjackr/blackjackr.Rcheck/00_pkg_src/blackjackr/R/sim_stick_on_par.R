#' Estimates player win rate with simple strategy
#' 
#' @description Simulates games where the player sticks on or above a chosen score. Inputting a score x, the player draws until their score is >= x.
#'
#' @param number_of_simulations Integer: The number of simulations used to approximate the player win rate.
#' @param range Vector: The values of x for which the simulation is carried out where x is the player's stick threshold.
#'
#' @return Numeric: An estimation of the player win rate.
#' @export
#'
#' @examples sim_stick_on_par(10^7, 11:21)
sim_stick_on_par = function(number_of_simulations, range){
  cl = parallel::makeCluster(parallel::detectCores())
  parallel::clusterExport(cl, c("sim_stick_on"), envir=environment())
  output =  parallel::parLapply(cl,range,fun =  function(x)(sim_stick_on(n = number_of_simulations,  stick_on = x)))
  parallel::stopCluster(cl)
  output = unlist(output)
  names(output) = range
  return(output)
}