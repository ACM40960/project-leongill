#' Outputs the cards in a position as a vector
#'
#' @description Given an index returns the associated player hand as a vector with the dealer's visible card at the end.
#'
#' @param index Numeric/Character: The index describing the position of interest.
#'
#' @return Vector: Vector of the cards in the position associated with the index.
#' @export
#'
#' @examples hand(101100000100)
hand = function(index){
  invisible(options(scipen=999) )
  current_hand = c()
  index = strsplit(as.character(index), "")[[1]]
  dealer_card = as.integer(index[2])
  index = rev(index[2:length(index)])
  for(i in 1:10){
    current_hand = c(current_hand, rep(i-1,as.integer(index[i])))
  }
  return(c(current_hand,dealer_card))
}
