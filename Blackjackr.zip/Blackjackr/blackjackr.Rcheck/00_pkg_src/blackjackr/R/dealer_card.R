#' Determines which dealer cards can match with the inputted player hand
#' 
#' @description The player hand is inputted with a hashmap. This function determines all of the possible dealer visible cards which could exist given the hands in the player's hand. These are then added as keys to the inputted dictionary. 
#'
#' @param i Numeric: The index describing the player hand with the dealer card set to 0. For information on the indexing system, see section 1 of the accompanying thesis document.
#' @param my_dict Hashmap: The hashmap to which the valid positions will be added.
#'
#' @return Hashmap: The same hashmap that was inputted with the new valid hands added .
#' @export
#'
#' @examples dealer_card(101100000100, my_dict)
dealer_card = function(i,my_dict){
  temp = i
  i = strsplit(as.character(i), "")[[1]]
  i = rev(i[2:length(i)])
  for(j in 1:10){
    if(as.integer(i[j]) < 4){#timesdecks
      my_dict[[as.character(temp + 10000000000*(j-1))]] = as.numeric(0)}}
  return(my_dict)}
