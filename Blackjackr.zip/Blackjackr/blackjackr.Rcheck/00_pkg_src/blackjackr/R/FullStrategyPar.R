#' Obtains an optimal strategy for a specified rule with MC simulations done in parallel
#' @description Produces a hashmap describing the optimal strategy for blackjack. The values of the hashmap 0,1,2,3 and 4 describe stick, hit, double down, surrender and split respectively.
#'
#' @param number_of_simulations Integer: The number of simulations used to approximate the expected player return when sticking on each position.
#' @param include_double_down Logical: Whether double down is permitted in your choice of game.
#' @param include_surrender Logical: Whether surrender is permitted in your choice of game.
#'
#' @return Hashmap: Hashmap with keys representing positions and values representing the optimal choice given the specified rules.
#' @export
#'
#' @examples full_strategy_par(number_of_simulations = 10^5, include_double_down = F, include_surrender = F)
full_strategy_par = function(number_of_simulations, include_double_down = F, include_surrender = F){
    invisible(options(scipen=999) )
    baseline = 10^11
    my_dict = hash::hash()
    new = c()
    powers = hash::hash("0" = 1,"1" = 10,"2" = 100,"3" = 1000,"4" = 10^4,"5" = 10^5,"6" = 10^6,"7" = 10^7,"8" = 10^8,"9" = 10^9,"10" = 10^10)#probabily slower w/ char conversion
    for(i in 0:9){
      if(score(baseline + powers[[as.character(i)]]) < 21){
        new = c(new,baseline + powers[[as.character(i)]]) #not adding one card stuff
      }
    }
    done = 0
    while(done == 0){
      previous = new
      new = c()
      for(index in previous){
        cards = as.list(strsplit(as.character(index), "")[[1]])
        cards =  rev(i[2:length(cards)])
        for(i in 0:9){
          if(score(index + powers[[as.character(i)]]) < 22){#If the score is valid
            if(is.numeric(my_dict[[as.character(index + powers[[as.character(i)]])]]) == F){#If we have not seen it before
              if(max(strsplit(as.character(index + powers[[as.character(i)]]), "")[[1]]) < as.character(4*1 + 1)){#If it doesnt have too many of a particular card
                if(!((index + powers[[as.character(i)]]) %in% new)){#If it is
                  new = c(new,index + powers[[as.character(i)]])
                  my_dict = dealer_card(index + powers[[as.character(i)]], my_dict)}}}}}}
      if(length(new) == 0){
        done = 1}
    }
    scores = hash::hash(names(my_dict), sapply(names(my_dict), score))
    hand_size = hash::hash(names(my_dict), sapply(names(my_dict), FUN = function(x)(length(hand(x))-1)))
    
    #-------------------------------------------------------------------------
    
    cards = hash::hash()
    labels = names(scores)
    for(i in labels){cards[[i]] = hand(i)}
    #-------------------------------------------------------------------------   
    cl = parallel::makeCluster(parallel::detectCores())
    parallel::clusterExport(cl, c("stick_probability", "trial"), envir=environment())

    stick_return = hash::hash(labels,
                        unlist(parallel::parLapply(cl,
                        labels,
                        fun =  function(x)(stick_probability(count = number_of_simulations, player_score = scores[[x]] , base_hand =  cards[[x]])))))
    parallel::stopCluster(cl)
    #-------------------------------------------------------------------------   
    
    labels = names(stick_return)
    hit_return = hash::hash(labels, -1)#Could just make equl to stick as we edit all values later
    
    for(i in labels){
      if(hand_size[[i]] == 2){
        if(scores[[i]] == 21){
          stick_return[[i]] = 2*stick_return[[i]]}}}#Blackjack gets double score
    
    for(current_num in 10:2){
      for(i in labels){#problem
        if(hand_size[[i]] == current_num){
          expected_value = 0
          current_hand = cards[[i]]
          hit_return[[i]] = 0
          for(j in 0:9){
            temp = as.character(as.numeric(i) + 10^j)
            p = probability(current_hand, j)
            if(p != 0){
              if(score(temp)< 22){
                if(stick_return[[temp]] >= hit_return[[temp]]){
                  expected_value = expected_value + p*stick_return[[temp]]}
                if(stick_return[[temp]] < hit_return[[temp]]){
                  expected_value = expected_value + p*hit_return[[temp]]}
              }}
            if(score(temp) > 21){
              expected_value = expected_value - p}
          }
          hit_return[[i]] = expected_value
        }}}
    
    #integrate double down
    double_return = hash::hash(labels,-2)
    if(include_double_down == T){
      for(i in labels){
        if(hand_size[[i]] == 2){
          double_value = 0
          for(j in 0:9){
            p = probability(cards[[i]], j)
            val = stick_return[[as.character(as.numeric(i) + 10^j)]]
            if(is.null(val)){double_value = double_value - p}
            if(is.null(val) == FALSE){double_value = double_value + p*val}
          }
          double_return[[i]] = double_value*2
        }}}
    surrender = hash::hash(labels, -2)
    if(include_surrender == T){
      for(i in labels){
        if(hand_size[[i]] == 2){
          surrender[[i]] = as.integer(hit_return[[i]] < -.5 & stick_return[[i]] < -.5)*5 - 2}
      }}
    
    
    #Choose optimal move for each position
    
    optimal = hash::hash(labels,0)
    
    for(i in labels){
      optimal[[i]] = which.max(c(stick_return[[i]], hit_return[[i]], double_return[[i]], surrender[[i]])) - 1}
    return(optimal)
}
    
  