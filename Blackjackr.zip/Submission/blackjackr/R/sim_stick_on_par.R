#' Estimates player win rate with simple strategy.
#' 
#' @description Simulates games where the player sticks on or above a chosen score. Inputting a score x, the player draws until their score is >= x.
#'
#' @param number_of_simulations Integer: The number of simulations used to approximate the player win rate.
#' @param range Vector: The values of x for which the simulation is carried out where x is the player's stick threshold.
#' @param cores Integer: The number of cores to use on the computation. Default is all. 
#'
#' @return Numeric: The ratio of player wins to toal games.
#' @export
#'
#' @examples sim_stick_on_par(10^7, 11:21)
sim_stick_on_par = function(number_of_simulations = 10^7, range = 10:21, cores = parallel::detectCores()){
  cl = parallel::makeCluster(cores)
  parallel::clusterExport(cl, c("sim_stick_on"), envir=environment())
  output =  parallel::parLapply(cl,range,fun =  function(x)(sim_stick_on(n = number_of_simulations,  stick_on = x)))
  parallel::stopCluster(cl)
  output = unlist(output)
  names(output) = range
  return(output)
}